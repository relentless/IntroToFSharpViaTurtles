Turtles
=======

A go at using [FParsec](http://www.quanttec.com/fparsec/) to create a very limited [Logo](http://en.wikipedia.org/wiki/Logo_(programming_language)) interpreter in F# which can draw [turtle graphics](http://en.wikipedia.org/wiki/Turtle_graphics).

From [Phil Trelford's FParsec Tutorial](http://trelford.com/blog/post/FParsec.aspx).
